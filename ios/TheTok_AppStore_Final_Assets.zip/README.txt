TheTok — App Store final screenshot assets

Master sets prepared for App Store Connect:
- iPhone 6.9-inch: 1320 x 2868 portrait, 10 JPEG
- iPad 13-inch: 2752 x 2064 landscape, 10 JPEG

Composition policy:
- UI screenshots with the exact iPhone aspect ratio were only rescaled and lightly sharpened.
- Other images were preserved in full and placed over a blurred extension derived from the same image.
- No generative edits were applied to UI text, prices, buttons or app content.
- RGB JPEG, no alpha channel.

Apple can scale these master sets to smaller display classes when the UI is equivalent.
